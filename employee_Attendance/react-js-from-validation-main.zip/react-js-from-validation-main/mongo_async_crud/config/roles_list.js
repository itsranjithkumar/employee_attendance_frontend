const ROLES_LIST = {
    "Admin": 5150,
    "Editor": 1984,
    "User": 2001
}

module.exports = ROLES_LIST