first step

To install the application - npx create-react-app app 

rm -rf .git - to remove force